// Initialize
var cWidth = window.innerWidth;
var cHeight = window.innerHeight;
var rLocX = new Array();
var rLocY = new Array();
var rSize = new Array();
var starCount = 20;
var isNight = false;
var moon = new moon();
var moonX = -90;
var moonY = cHeight/2;
var sun = new sun();
var sunX = -100;
var sunY = cHeight/2;
var a = (2*cHeight)/(cWidth**2);
for(var i = 0; i < starCount; i++) {
  rLocX[i] = Math.floor((Math.random() * (cWidth - 100)) + 100);
  rLocY[i] = Math.floor((Math.random() * (cHeight - 100)) + 100);
  rSize[i] = Math.floor((Math.random() * 4) + 2);
}
var fadeAmount = 4;
var fade = -fadeAmount;
var cloudA = new Array();
var cloudXA = new Array();
var cloudYA = new Array();
var cloudSize = 24;
var cloudCount = 10;

for(i = 0; i < cloudCount; i++) {
  cloudXA[i] = -1*Math.floor((Math.random() * (2*cWidth)) + 60);
  cloudYA[i] = Math.floor((Math.random() * ((.85*cHeight)-40)) + ((.15*cHeight)+40));
}

// Functions
function setup() {
  createCanvas(cWidth, cHeight);
}

function draw() {
  //let colorDay = color(135,206,235);
  let colorDay = color(199, 228, 255);
  let colorNight = color(0,26,51);
  let lerp;
  if(isNight == true) { lerp = lerpColor(colorNight,colorDay,gradVal(moonX)); }
  else { lerp = lerpColor(colorDay,colorNight,gradVal(sunX)); }
  background(lerp); 
  // Moon and Sun
  if (isNight == true) {
    noStroke();
    for(i = 0; i < starCount; i++) {
      fill(248, 222, 126, fade);
      star(rLocX[i], rLocY[i], 2 * rSize[i], 5 * rSize[i], 4);
    }
    if (fade < 0) {
      fadeAmount = 4;
      for(i = 0; i < 10; i++) {
        rSize[i] = Math.floor((Math.random() * 4) + 2);
        rLocX[i] = Math.floor((Math.random() * (cWidth - 100)) + 100);
        rLocY[i] = Math.floor((Math.random() * (cHeight - 100)) + 100);
      }
    }
    if (fade > 255) { fadeAmount = -4; }
    fade += fadeAmount;
    moon.show();
    moon.move();
  }
  else {
    for(i = 0; i < cloudCount; i++) {
      cloudA[i] = new cloud();
      cloudA[i].show(cloudXA[i],cloudYA[i]);
      cloudA[i].move(i);
    }
    sun.show();
    sun.move();
  }
}

function star(x, y, radius1, radius2, sides) {
  let angle = TWO_PI / sides;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function moon() {
  this.show = function() {
    noStroke();
    fill(230,230,180);
    ellipse(moonX,moonY,150);
    fill(170,170,56);
    ellipse((moonX-20),(moonY+40),40);
    ellipse((moonX-35),(moonY+20),25);
    ellipse((moonX-60),(moonY+20),10);
    ellipse((moonX-15),(moonY),15);
    ellipse((moonX-50),(moonY-20),20);
    ellipse((moonX-35),(moonY-40),10);
    ellipse((moonX-15),(moonY-40),20);
    ellipse((moonX-5),(moonY-50),25);
    ellipse((moonX+15),(moonY-30),20);
    ellipse((moonX+20),(moonY-50),10);
    ellipse((moonX+40),(moonY+10),30);
    ellipse((moonX+25),(moonY+55),20);
    ellipse((moonX+45),(moonY+50),10);
  }
  this.move = function() {
    moonX += 1;
    moonY = a*((moonX-(cWidth/2))**2);
    if(moonX > cWidth+90) {
      for(i = 0; i < cloudCount; i++) {
        cloudXA[i] = -1*Math.floor((Math.random() * (2*cWidth)) + 60);
        cloudYA[i] = Math.floor((Math.random() * ((.85*cHeight)-40)) + ((.15*cHeight)+40));
      }
      isNight = false;
      sunX = -100;
    }
  }
}

function sun() {
  this.show = function() {
    noStroke();
    fill(203,100,0);
    star(sunX,sunY,80,100,13);
    fill(253, 184, 19);
    ellipse(sunX,sunY,150);
  }
  this.move = function() {
    sunX += 1;
    sunY = a*((sunX-(cWidth/2))**2);
    fade = -4;
    if(sunX > cWidth+90) {
      isNight = true;
      moonX = -90;
    }
  }
}

function cloud() {
  this.show = function(x, y) {
    stroke(255);
    strokeWeight(2);
    fill(255);
    rectMode(CENTER);
    rect(x,y,150,50);
    ellipse(x-75,y-25,100);
    ellipse(x-50,y-75,50);
    ellipse(x+25,y-75,125);
    ellipse(x+75,y-25,100);
    ellipse(x-10,y-25,50);
  }
  this.move = function(i) { cloudXA[i] += 3; } 
}

function gradVal(x) {
  let gradVal;
  if(x <= (cWidth/2) && x > 0) { gradVal = (1/2)-(x/cWidth); }
  else if(x > (cWidth/2) && x < cWidth) { gradVal = (x/cWidth)-(1/2); }
  else { gradVal = 1/2; }
  return gradVal;
}