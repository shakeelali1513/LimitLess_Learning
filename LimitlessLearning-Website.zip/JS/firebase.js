const firebaseConfig = {
  apiKey: "AIzaSyD4LLRQjB0U3YFr5up3VVp4xsXrS5fnQXc",
  authDomain: "limitless-learning.firebaseapp.com",
  databaseURL: "https://limitless-learning.firebaseio.com",
  projectId: "limitless-learning",
  storageBucket: "limitless-learning.appspot.com",
  messagingSenderId: "288748191256",
  appId: "1:288748191256:web:0aadcfc59a69b902920d6d",
  measurementId: "G-NHD4QJKZHP"
};

firebase.initializeApp(firebaseConfig);
firebase.analytics();

const auth = firebase.auth(); 

function signUp() {
  var email = document.getElementById("email");
  var pass1 = document.getElementById("pass1");
  var err = document.getElementById("errbox");
  var db = firebase.firestore();
  var user = firebase.auth().currentUser;
  var fn = document.getElementById('fn').value;
  var ln = document.getElementById('ln').value;
  err.innerHTML = "";
  auth.createUserWithEmailAndPassword(email.value, pass1.value).then(cred => {
    return db.collection('users').doc(cred.user.uid).set({
      displayName: fn + " " + ln,
      profession: document.getElementById("toggleText").textContent
    })
  })
}

function signIn() {
  var email = document.getElementById("email");
  var pass1 = document.getElementById("pass1");
  var err = document.getElementById("errbox");
  err.innerHTML = "";
  const promise = auth.signInWithEmailAndPassword(email.value, pass1.value);
  promise.catch(e => err.innerHTML = e.message);
}

function signOut() {
  auth.signOut();
}


auth.onAuthStateChanged(function(user) {
  if (user) {
    var email = user.email;
    var db = firebase.firestore();
    var docRef = db.collection("users").doc(user.uid);
    document.getElementById('courses').style.visibility = "visible";
    docRef.get().then(function(doc) {
      if (doc.exists) {
        document.getElementById('currUserNav').innerHTML = doc.data().displayName;
      }
    }).catch(function(error) {
        console.log("Error getting document:", error);
    });

    docRef.get().then(function(doc) {
      var prof = doc.data().profession;
      var cqu = document.getElementById('courses');
    
      if (prof == 'STUDENT') {
        cqu.innerHTML = "COURSES";
        cqu.href = 'tutor.html';
      } else {
        cqu.innerHTML = "QUEUE";
        cqu.href = 'queue.html';
      }
    });

    document.getElementById('SignNavA').innerHTML = "SIGN OUT";
    document.getElementById('SignNavA').href = "";
    document.getElementById('SignNavA').onclick = function() { signOut() };
    locationRef();
  } else {
      document.getElementById('courses').style.visibility = "hidden";
  }
})

function locationRef() {
  var url = window.location.pathname;
  var filename = url.substring(url.lastIndexOf('/')+1);
  if (filename == 'signin.html') { location.href = 'index.html'; }
}

function writeUserData(userId, name, email) {
  firebase.database().ref('users/' + userId).set({
    username: name,
    email: email
  });
}