function mouseover() {
	lim.style.color = "white";
	lea.style.color = "#0ec8fe";
}

function mouseleave() {
	lim.style.color = "#0ec8fe";
	lea.style.color = "white";
}

window.onload = function() {
	var title = document.getElementById('title');
	var limit = document.getElementById('lim');
	var lea = document.getElementById('lea');
}